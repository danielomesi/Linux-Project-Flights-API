#!/bin/bash

sudo docker pull danielomesi/linux_ex03:dbservice

mkdir -p SharedFolder
sudo docker run -v "$(pwd)/SharedFolder:/home/SharedFolder" danielomesi/linux_ex03:dbservice
