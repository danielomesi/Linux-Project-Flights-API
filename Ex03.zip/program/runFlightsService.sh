#!/bin/bash

sudo docker pull danielomesi/linux_ex03:flightsservice

sudo docker run -it -v "$(pwd)/SharedFolder:/home/SharedFolder" danielomesi/linux_ex03:flightsservice
