#!/bin/bash

sudo docker run -it -v "$(pwd)/SharedFolder:/home/SharedFolder" flightsservice:1.0 bash
