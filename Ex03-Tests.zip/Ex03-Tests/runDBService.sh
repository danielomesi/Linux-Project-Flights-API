#!/bin/bash

mkdir -p SharedFolder
sudo docker run -v "$(pwd)/SharedFolder:/home/SharedFolder" dbservice:1.0
