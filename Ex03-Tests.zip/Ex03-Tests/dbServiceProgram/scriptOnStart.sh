#!/bin/bash

cd home/program
export LD_LIBRARY_PATH=.
cmake CMakeLists.txt
make
/home/program/dbService
